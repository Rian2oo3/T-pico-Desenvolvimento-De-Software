package Universidade;



//aqui é onde todo o código se starta na visão do usuário, puxamos o MenuPrincipal de modo que o usuário acesse o Menu, fazendo que se crie uma arvore de processor dependendo da escolha do próprio



import View.MenuPrincipal;

/**
 *
 * @author Samuel
 */
public class Universidade {

    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
    }

}
