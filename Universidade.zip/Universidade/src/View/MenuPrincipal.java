package View;

import java.util.Scanner;

/**
 *
 * @author Rian
 */
public class MenuPrincipal {

    private final Scanner scanner;

    public MenuPrincipal() {
        scanner = new Scanner(System.in);
        inicio();
    }

    private void inicio() {
        
        //Menu exibido pelo usuário
        
        System.out.println("-- MENU PRINCIPAL --");
        System.out.println("Opções: ");
        System.out.println("1 - Cadastrar Disciplina");
        System.out.println("2 - Cadastrar Aluno");
        System.out.println("3 - Matricular Aluno");
        System.out.println("4 - Lançar Notas");
        System.out.println("5 - Listar Notas");
        
        
        // Escolha de menu

        int opcao = Integer.valueOf(scanner.nextLine());

        
        
        switch (opcao) {
            case 1: {
                MenuDisciplina menu = new MenuDisciplina();
                menu.cadastrar();
                inicio();
                break;
            }
            case 2: {
                MenuAluno menu = new MenuAluno();
                menu.cadastrar();
                inicio();
                break;
            }
            case 3: {
                MenuHistorico menu = new MenuHistorico();
                menu.cadastrar();
                inicio();
                break;
            }
            case 4: {
                MenuHistorico menu = new MenuHistorico();
                menu.lançarNota();
                inicio();
                break;
            }
            case 5: {
                MenuHistorico menu = new MenuHistorico();
                menu.listar();
                inicio();
                break;
            }
            
            // Mensagem de erro 
            default: {
                System.out.flush();
                System.err.println("Digite um número válido!");
                inicio();
            }
        }
    }

}
